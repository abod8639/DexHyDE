public class Testo {
  public Testo(
    String a
  ) {
  }
}
