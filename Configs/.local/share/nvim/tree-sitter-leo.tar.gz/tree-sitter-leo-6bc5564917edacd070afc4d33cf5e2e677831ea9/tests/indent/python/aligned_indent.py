def aligned_indent(arg1,
                   arg2):
    pass

aligned_indent(1,
               2)


aligned_indent(1,
               2
               )

foodsadsa(sdada,
          2
