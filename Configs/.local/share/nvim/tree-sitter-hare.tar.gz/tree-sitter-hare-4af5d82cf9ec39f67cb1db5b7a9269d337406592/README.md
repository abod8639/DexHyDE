# tree-sitter-hare

[![Build Status](https://github.com/amaanq/tree-sitter-hare/actions/workflows/ci.yml/badge.svg)](https://github.com/amaanq/tree-sitter-hare/actions/workflows/ci.yml)
[![Discord](https://img.shields.io/discord/1063097320771698699?logo=discord)](https://discord.gg/w7nTvsVJhm)

[Hare](http://harelang.org) grammar for [tree-sitter](https://tree-sitter.github.io)
