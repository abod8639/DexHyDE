tree-sitter-ispc
================

[![build](https://github.com/fab4100/tree-sitter-ispc/actions/workflows/ci.yml/badge.svg)](https://github.com/fab4100/tree-sitter-ispc/actions/workflows/ci.yml)
[![crates.io](https://github.com/fab4100/tree-sitter-ispc/actions/workflows/publish_crate.yml/badge.svg)](https://github.com/fab4100/tree-sitter-ispc/actions/workflows/publish_crate.yml)

[ISPC](https://ispc.github.io/ispc.html) grammar for
[tree-sitter](https://github.com/maxbrunsfeld/tree-sitter) (based on
[tree-sitter-c](https://github.com/tree-sitter/tree-sitter-c)).
