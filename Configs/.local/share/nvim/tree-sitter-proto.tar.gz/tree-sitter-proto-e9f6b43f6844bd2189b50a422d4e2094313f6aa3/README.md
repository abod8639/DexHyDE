# tree-sitter-proto

[tree-sitter][] grammar for protocol buffer files (proto3 and basic proto2 support).

[tree-sitter]: https://github.com/tree-sitter/tree-sitter

## Status

The grammar should be complete. I'm still working on the highlighting queries.
I've tested the grammar against some really large and nasty proto files
and it passes. 
