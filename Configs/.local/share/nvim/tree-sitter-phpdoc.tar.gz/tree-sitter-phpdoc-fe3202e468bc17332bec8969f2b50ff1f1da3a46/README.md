# tree-sitter-phpdoc

PHPDoc grammar for [tree-sitter][].

[tree-sitter]: https://github.com/tree-sitter/tree-sitter

## Install

`npm install tree-sitter-phpdoc`

## Test

`npm test`

If this test script doesn't work for you, you can just run
`./node_modules/.bin/tree-sitter generate` and
`./node_modules/.bin/tree-sitter test` manually.

#### Thanks

Originally forked from https://github.com/john-nguyen09/tree-sitter-phpdoc
