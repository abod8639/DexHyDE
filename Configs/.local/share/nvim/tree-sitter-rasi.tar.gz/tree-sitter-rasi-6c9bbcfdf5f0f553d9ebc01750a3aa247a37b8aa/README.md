tree-sitter-rasi
==================

RASI grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter). Adapted from [the rofi-theme man page](https://man.archlinux.org/man/community/rofi/rofi-theme.5.en).

## No shame promotion
Check [rasi.vim plugin](https://github.com/Fymyte/rasi.vim)

