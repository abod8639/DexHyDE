module Main exposing (..)


func ab =
    case ab of
        True ->
            case ab of
                True ->
                    case ab of
                        True ->
                            case ab of
                                True ->
                                    case ab of
                                        True ->
                                            case ab of
                                                True ->
                                                    case ab of
                                                        True ->
                                                            case ab of
                                                                True ->
                                                                    case ab of
                                                                        True ->
                                                                            case ab of
                                                                                True ->
                                                                                    case ab of
                                                                                        True ->
                                                                                            case ab of
                                                                                                True ->
                                                                                                    case ab of
                                                                                                        True ->
                                                                                                            case ab of
                                                                                                                True ->
                                                                                                                    case ab of
                                                                                                                        True ->
                                                                                                                            case ab of
                                                                                                                                True ->
                                                                                                                                    case ab of
                                                                                                                                        True ->
                                                                                                                                            Just
                                                                                                                                                { s = 5
                                                                                                                                                }

                                                                                                                                        _ ->
                                                                                                                                            Nothing

                                                                                                                                _ ->
                                                                                                                                    Nothing

                                                                                                                                _ ->
                                                                                                                                    Nothing

                                                                                                                _ ->
                                                                                                                    Nothing

                                                                                                        _ ->
                                                                                                            Nothing

                                                                                                _ ->
                                                                                                    Nothing

                                                                                        _ ->
                                                                                            Nothing

                                                                                _ ->
                                                                                    Nothing

                                                                        _ ->
                                                                            Nothing

                                                                _ ->
                                                                    Nothing

                                                        _ ->
                                                            Nothing

                                                _ ->
                                                    Nothing

                                        _ ->
                                            Nothing

                                _ ->
                                    Nothing

                        _ ->
                            Nothing

                _ ->
                    Nothing

        _ ->
            Nothing
