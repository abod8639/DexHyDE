# tree-sitter-qmldir

[![Build Status](https://github.com/Decodetalkers/tree-sitter-qmldir/actions/workflows/ci.yml/badge.svg)](https://github.com/Decodetalkers/tree-sitter-qmldir/actions/workflows/ci.yml)
[![Discord](https://img.shields.io/discord/1063097320771698699?logo=discord)](https://discord.gg/w7nTvsVJhm)

[Qmldir](https://doc.qt.io/qt-6/qtqml-modules-qmldir.html) grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter)

![Highlights example](https://user-images.githubusercontent.com/29718261/222028352-96525a6a-5b01-47a8-a9f3-9bb322b4dfe9.png)
