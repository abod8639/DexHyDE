[FIRRTL](https://www.chisel-lang.org/firrtl/) grammar for [tree-sitter](https://tree-sitter.github.io)
