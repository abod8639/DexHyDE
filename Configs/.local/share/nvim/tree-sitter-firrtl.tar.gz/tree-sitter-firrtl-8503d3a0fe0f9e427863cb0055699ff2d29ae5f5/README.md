# tree-sitter-firrtl

[![NPM version](https://img.shields.io/npm/v/tree-sitter-firrtl.svg)](https://www.npmjs.org/package/tree-sitter-firrtl)
[![Build Status](https://github.com/chipsalliance/tree-sitter-firrtl/actions/workflows/ci.yml/badge.svg)](https://github.com/chipsalliance/tree-sitter-firrtl/actions/workflows/ci.yml)
[![Discord](https://img.shields.io/discord/1063097320771698699?logo=discord)](https://discord.gg/w7nTvsVJhm)

[FIRRTL](https://www.chisel-lang.org/firrtl) grammar for [tree-sitter](https://tree-sitter.github.io)
