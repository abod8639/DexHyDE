# tree-sitter-ralph

`Ralph` is the smart contract programming language for the [Alephium blockchain](https://alephium.org/)

[Github](https://github.com/alephium)
[Discord](https://discord.gg/XC5JaaDT7z)
[Telegram](https://t.me/alephiumgroup)

Ralph grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter)

## References

[Ralph wiki](https://docs.alephium.org/ralph/getting-started)
