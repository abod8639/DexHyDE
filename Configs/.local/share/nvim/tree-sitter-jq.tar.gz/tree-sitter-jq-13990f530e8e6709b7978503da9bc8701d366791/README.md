# tree-sitter-jq
tree-sitter grammar for jq
