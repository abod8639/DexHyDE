# tree-sitter-liquidsoap

Liquidsoap grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter).
