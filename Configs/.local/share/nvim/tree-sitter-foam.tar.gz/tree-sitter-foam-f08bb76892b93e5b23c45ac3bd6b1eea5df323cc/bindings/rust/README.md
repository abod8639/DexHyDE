# tree-sitter-foam

This crate provides an OpenFOAM grammar for the [tree-sitter](https://tree-sitter.github.io/tree-sitter/) parsing library.
To use it, add to your `[dependencies]`.

Typically, you'll want to also depend on `tree-sitter` itself, so you can
parse and highlight code using this crate.

