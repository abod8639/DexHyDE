const defineGrammar = require('../common/define-grammar.js');

module.exports = defineGrammar('php_only');
