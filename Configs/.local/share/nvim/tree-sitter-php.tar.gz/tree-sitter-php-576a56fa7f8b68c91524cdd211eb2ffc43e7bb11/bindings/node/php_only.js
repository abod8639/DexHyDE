module.exports = require('.').php_only;
