---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!--
     The tree-sitter-erlang project is an Erlang parser only.
     How can we improve it?
-->
