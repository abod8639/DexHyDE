"Erlang grammar for tree-sitter"
# @generated
from ._binding import language

__all__ = ["language"]
