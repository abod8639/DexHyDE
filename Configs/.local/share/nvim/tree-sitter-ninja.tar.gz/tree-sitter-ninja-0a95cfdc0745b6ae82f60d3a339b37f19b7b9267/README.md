# tree-sitter-ninja
[ninja](https://github.com/ninja-build/ninja/) grammar for tree-sitter
