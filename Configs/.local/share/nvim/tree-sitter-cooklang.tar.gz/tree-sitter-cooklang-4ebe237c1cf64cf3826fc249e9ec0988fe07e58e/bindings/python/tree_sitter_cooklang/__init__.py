"Cooklang grammar for tree-sitter"

from ._binding import language

__all__ = ["language"]
