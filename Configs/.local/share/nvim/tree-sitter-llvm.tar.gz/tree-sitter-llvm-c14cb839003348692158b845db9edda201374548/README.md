Treesitter parser for LLVM

Based on [LLVM's existing bindings](https://github.com/llvm/llvm-project/blob/main/llvm/utils/).
