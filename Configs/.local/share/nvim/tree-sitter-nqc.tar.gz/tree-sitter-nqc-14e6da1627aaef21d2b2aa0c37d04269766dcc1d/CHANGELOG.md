# Changelog

## 1.0.0 (2023-08-31)


### Features

* Initial commit ([d8cebf0](https://github.com/amaanq/tree-sitter-nqc/commit/d8cebf03341d85ddef0ef590517446f9373b6fa8))
