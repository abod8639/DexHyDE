# tree-sitter-nqc

[![CI](https://github.com/amaanq/tree-sitter-nqc/actions/workflows/ci.yml/badge.svg)](https://github.com/amaanq/tree-sitter-nqc/actions/workflows/ci.yml)
[![Discord](https://img.shields.io/discord/1063097320771698699?logo=discord)](https://discord.gg/w7nTvsVJhm)

[NQC](https://bricxcc.sourceforge.net/nqc/) grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter)
