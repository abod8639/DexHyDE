do {} while (a);
// <- keyword
//     ^ keyword

try {} catch (e) {} finally {}
// <- keyword
//     ^ keyword
//                  ^ keyword

throw e
// <- keyword
//    ^ variable
