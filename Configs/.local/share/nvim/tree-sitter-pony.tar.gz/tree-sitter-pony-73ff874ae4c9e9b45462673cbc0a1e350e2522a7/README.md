# tree-sitter-pony

[![Build Status](https://github.com/amaanq/tree-sitter-pony/actions/workflows/ci.yml/badge.svg)](https://github.com/amaanq/tree-sitter-pony/actions/workflows/ci.yml)
[![Discord](https://img.shields.io/discord/1063097320771698699?logo=discord)](https://discord.gg/w7nTvsVJhm)

[Pony](https://www.ponylang.io/) grammar for [tree-sitter](https://tree-sitter.github.io)
