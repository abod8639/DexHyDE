.. role:: action

Hello... `(beat)`:action: ...there!
