Test footnote and citation rendering
************************************

Paragraphs may contain footnote references (manually numbered
[1]_, anonymous auto-numbered [#]_, labeled auto-numbered [#label]_, or
symbolic [*]_) or citation references ([CIT2002]_, [DU2015]_).

.. include:: data/standard.txt
   :start-after: Footnotes
                 ---------   
   :end-before: Here's a reference to the above, [CIT2002]_,
   
.. [DU2015] `Example document`, Hometown: 2015.

Here's a reference to the above, [CIT2002]_.

.. [5] this footnote is missing in the standard example document.
