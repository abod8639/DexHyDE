.. role:: action
   :class: action parenthetical direction

Hello... `(beat)`:action: ...there!
