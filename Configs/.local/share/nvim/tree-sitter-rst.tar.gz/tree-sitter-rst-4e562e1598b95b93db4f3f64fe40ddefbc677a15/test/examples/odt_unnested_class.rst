.. role:: action
   :class: action

Hello... `(beat)`:action: ...there!
