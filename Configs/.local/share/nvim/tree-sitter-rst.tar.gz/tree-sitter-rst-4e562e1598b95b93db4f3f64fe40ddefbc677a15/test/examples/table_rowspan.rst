Rowspanning tables
------------------

Here's a table with cells spanning several rows:

+------------------------+------------+------------------+
| Header row, column 1   | Header 2   | Header 3         |
| (header rows optional) |            |                  |
+========================+============+==================+
| body row 1, column 1   | column 2   | column 3         |
+------------------------+------------+------------------+
| body row 2             | Cells may  | Another          |
+------------------------+ span rows. | rowspanning      |
| body row 3             |            | cell.            |
+------------------------+------------+------------------+
