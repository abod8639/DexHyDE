========
Test raw
========

Some cheese.

.. raw:: odt

   <text:p>what now ?</text:p>

None in shop.
