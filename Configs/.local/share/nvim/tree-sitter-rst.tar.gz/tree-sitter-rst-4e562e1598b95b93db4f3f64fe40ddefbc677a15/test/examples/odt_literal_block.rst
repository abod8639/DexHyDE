literal block ::

  ~~~ ><> ~~ <>< ~~~

