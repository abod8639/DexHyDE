=================
Table of contents
=================

.. contents::

In short
========

Regression to test table of contents construction

End
===

this
