Section titles with `inline markup`_ 
------------------------------------

*emphasized*, H\ :sub:`2`\ O and :math:`x^2`
````````````````````````````````````````````
Substitutions |fail|
````````````````````
.. |fail| replace:: work

Deeply nested sections
----------------------
In LaTeX and HTML,

Level 3
```````
nested sections

level 4
^^^^^^^
reach at some level 

level 5
:::::::
(depending on the document class)

level 6
+++++++
an unsupported level.
