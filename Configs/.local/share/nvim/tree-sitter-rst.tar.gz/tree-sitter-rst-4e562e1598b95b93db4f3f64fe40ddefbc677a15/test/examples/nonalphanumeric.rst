Monospaced non-alphanumeric characters
--------------------------------------

These are all ASCII characters except a-zA-Z0-9 and space:

``!!!"""###$$$%%%&&&'''((()))***+++,,,---...///:::``

``;;;<<<===>>>???@@@[[[\\\]]]^^^___```{{{|||}}}~~~``

``xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx``

The two lines of non-alphanumeric characters should both have the same
width as the third line.
