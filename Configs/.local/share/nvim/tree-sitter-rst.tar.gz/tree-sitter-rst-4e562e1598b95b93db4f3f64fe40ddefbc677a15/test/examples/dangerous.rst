Potentially dangerous features (security holes):

.. include:: /etc/passwd
.. raw:: html
   :file: /etc/passwd
.. raw:: html
   :url: file:///etc/passwd
.. raw:: html

   <script>
       that does something really nasty
   </script>
.. csv-table:: :file: /etc/passwd
.. csv-table:: :url: file:///etc/passwd
.. figure:: picture.png
   :figwidth: image
