# tree-sitter-nix

[![Build Status](https://github.com/nix-community/tree-sitter-nix/actions/workflows/nix-github-actions.yml/badge.svg)](https://github.com/nix-community/tree-sitter-nix/actions/workflows/nix-github-actions.yml)

Nix grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter).
