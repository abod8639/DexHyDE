# tree-sitter-gitignore

A tree-sitter parser for `.gitignore` files.

