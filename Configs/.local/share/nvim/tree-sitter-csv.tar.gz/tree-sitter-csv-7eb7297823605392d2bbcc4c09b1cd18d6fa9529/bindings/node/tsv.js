module.exports = require('./index').tsv;
