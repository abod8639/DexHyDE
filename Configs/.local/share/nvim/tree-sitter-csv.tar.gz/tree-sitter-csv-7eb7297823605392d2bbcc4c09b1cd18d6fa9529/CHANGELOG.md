# Changelog

## [1.2.0](https://github.com/amaanq/tree-sitter-csv/compare/v1.1.1...v1.2.0) (2023-08-31)


### Features

* add hex numbers ([6c19574](https://github.com/amaanq/tree-sitter-csv/commit/6c1957405bd6f7751b050f61367f1094fab91444))

## [1.1.1](https://github.com/amaanq/tree-sitter-csv/compare/v1.1.0...v1.1.1) (2023-08-18)


### Bug Fixes

* don't parse numbers as text ([bf0f53a](https://github.com/amaanq/tree-sitter-csv/commit/bf0f53a6bf4ad1c403d34e281c036abd5996dd7b))

## [1.1.0](https://github.com/amaanq/tree-sitter-csv/compare/v1.0.0...v1.1.0) (2023-08-17)


### Features

* add PSV support ([1e1c291](https://github.com/amaanq/tree-sitter-csv/commit/1e1c291e6488867322442f6ca6f445e05fc52253))

## 1.0.0 (2023-08-17)


### Features

* initial commit ([b24a804](https://github.com/amaanq/tree-sitter-csv/commit/b24a804d90452cd15ff7e6829d62f0eb1ad5266e))
