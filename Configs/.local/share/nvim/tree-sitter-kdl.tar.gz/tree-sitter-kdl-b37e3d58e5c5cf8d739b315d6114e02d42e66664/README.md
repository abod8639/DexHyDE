# tree-sitter-kdl

[![Build Status](https://github.com/amaanq/tree-sitter-kdl/actions/workflows/ci.yml/badge.svg)](https://github.com/amaanq/tree-sitter-kdl/actions/workflows/ci.yml)
[![Discord](https://img.shields.io/discord/1063097320771698699?logo=discord)](https://discord.gg/w7nTvsVJhm)

KDL grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter)

Adapted from the [official spec](https://github.com/kdl-org/kdl/blob/main/SPEC.md)
