# tree-sitter-inko

An [Inko](https://inko-lang.org/) grammar for
[Tree-sitter](https://tree-sitter.github.io/tree-sitter/).

## License

All source code in this repository is licensed under the Mozilla Public License
version 2.0, unless stated otherwise. A copy of this license can be found in the
file "LICENSE".
